

s1 = "abcd"
s2= "abcde"
l1 = list(s1)
l2 = list(s2)
for i in l1:
    l2.remove(i)
print(f'找到了s2中被添加的字母{l2}')








